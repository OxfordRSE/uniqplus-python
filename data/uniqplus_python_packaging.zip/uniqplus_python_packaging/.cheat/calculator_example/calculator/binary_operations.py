def add(a, b):
    return a + b


def mult(a, b):
    return a * b
