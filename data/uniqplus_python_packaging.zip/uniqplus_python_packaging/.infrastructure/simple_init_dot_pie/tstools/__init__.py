from os.path import basename
filename = basename(__file__)
print(f"Hello from {filename}")
